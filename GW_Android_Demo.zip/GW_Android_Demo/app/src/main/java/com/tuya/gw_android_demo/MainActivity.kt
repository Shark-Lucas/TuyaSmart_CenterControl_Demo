package com.tuya.gw_android_demo

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() , View.OnClickListener{

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.noAbilityGw).setOnClickListener(this)


    }

    override fun onClick(v: View?) {
        when(v?.id) {
            R.id.noAbilityGw -> {
                val intent = Intent(this, NoAbilityGW::class.java)
                startActivity(intent)
            }
            R.id.zbAbilityGW -> {
                val intent = Intent(this, ZbAbilityGW::class.java)
                startActivity(intent)
            }
            R.id.ownAbilityGW -> {
                val intent = Intent(this, OwnAbilityGW::class.java)
                startActivity(intent)
            }
        }
    }
}