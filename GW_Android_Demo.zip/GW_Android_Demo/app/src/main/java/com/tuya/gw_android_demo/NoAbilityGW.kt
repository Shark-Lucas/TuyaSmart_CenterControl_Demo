package com.tuya.gw_android_demo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.tuya.libiot.TuyaIotSdk
import com.tuya.libiot.interfaces.IotCallbacks
import com.tuya.libiot.model.DataPoint
import com.tuya.libiot.model.IotConfig

class NoAbilityGW : AppCompatActivity() {
    private var mIot : TuyaIotSdk? = null
    private val TAG = "NoAbilityGW"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_no_ability_gw)

        mIot = TuyaIotSdk.getInstance()
        mIot?.setIotCallbacks(iotCallback)

        val cfg = IotConfig()
        cfg.mFirmwareKey = "keyuqugcq8rrtadw"
        cfg.mUUID = "ae31b763a6780154"
        cfg.mAuthKey = "hdJQznrzbjBAp2RYpWs8R1plgIXgGWB2"
        mIot?.tuyaIotStart(this, cfg)
    }

    var iotCallback = object : IotCallbacks{
        override fun onStartSuccess() {
            Log.d(TAG, "onStartSuccess")
        }

        override fun onStartFailure(p0: Int) {
            Log.d(TAG, "onStartFailure")
        }

        override fun onStatusChanged(p0: Int) {
            Log.d(TAG, "onStatusChanged")
        }

        override fun onReset(p0: Int) {
            Log.d(TAG, "onReset")
        }

        override fun onReboot() {
            Log.d(TAG, "onReboot")
        }

        override fun onDataPointCommand(
            p0: Int,
            p1: Int,
            p2: String?,
            p3: String?,
            p4: Array<out DataPoint>?
        ) {
            Log.d(TAG, "onDataPointCommand")
        }

        override fun onRawDataPointCommand(
            p0: Int,
            p1: Int,
            p2: String?,
            p3: Int,
            p4: String?,
            p5: ByteArray?
        ) {
            Log.d(TAG, "onRawDataPointCommand")
        }

        override fun onDataPointQuery(p0: String?, p1: IntArray?) {
            Log.d(TAG, "onDataPointQuery")
        }

        override fun onNetworkStatus(p0: Int) {
            Log.d(TAG, "onNetworkStatus")
        }

        override fun onGetLogFile(): String {
            Log.d(TAG, "onGetLogFile")
            return ""
        }
    }

}