package com.tuya.gw_android_demo

import android.app.Application
import com.tuya.smart.home.sdk.TuyaHomeSdk

class TuyaSmartApp : Application() {
    companion object {
        var instance: TuyaSmartApp ?= null
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        TuyaHomeSdk.init(this)
        TuyaHomeSdk.setDebugMode(true)
    }
}