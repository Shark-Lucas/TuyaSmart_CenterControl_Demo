package com.tuya.gw_android_demo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ZbAbilityGW : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_zb_ability_gw)
    }
}